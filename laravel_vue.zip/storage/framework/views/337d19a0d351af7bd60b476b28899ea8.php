<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Option 1: Include in HTML -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">


        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
        <!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
        <!-- Owl Carousel Theme Default CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
        <!-- Box Icon CSS-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/boxicon.min.css')); ?>">
        <!-- Flaticon CSS-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/flaticon/flaticon.css')); ?>">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.css')); ?>">
        <!-- Style CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
		<!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.png')); ?>">  



        <!-- Scripts -->
        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>


        <!-- Back To Top Start -->
		<div class="top-btn">
			<i class='bx bx-chevrons-up bx-fade-up'></i>
		</div>
		<!-- Back To Top End -->



        <!-- jQuery first, then Bootstrap JS -->
		<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
		<!-- Owl Carousel JS -->
		<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
		<!-- Nice Select JS -->
		<script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
		<!-- Magnific Popup JS -->
		<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
		<!-- Subscriber Form JS -->
		<script src="<?php echo e(asset('assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
		<!-- Form Velidation JS -->
		<script src="<?php echo e(asset('assets/js/form-validator.min.js')); ?>"></script>
		<!-- Contact Form -->
		<script src="<?php echo e(asset('assets/js/contact-form-script.js')); ?>"></script>
		<!-- Meanmenu JS -->
		<script src="<?php echo e(asset('assets/js/meanmenu.js')); ?>"></script>
		<!-- Custom JS -->
		<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    </body>
</html>
<?php /**PATH E:\php8.2.12\htdocs\Laravel_Vue\laravel_vue\resources\views/app.blade.php ENDPATH**/ ?>