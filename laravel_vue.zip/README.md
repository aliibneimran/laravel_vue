This is Job Portal Website
Fretures: Job seeker login/signup,update his profile, apply job, company can also login/signup, update thair profile, post job, admin can access everything. searching job (continue)
admin: path = admin/login, email = admin@gmail.com, password = 123456
